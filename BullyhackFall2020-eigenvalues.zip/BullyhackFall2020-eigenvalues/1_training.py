# import cv2, os
# import numpy as np
# from PIL import Image
#
# recognizer = cv2.face.EigenFaceRecognizer_create()
# # detector_a = cv2.CascadeClassifier("./dataset/haarcascade_frontalface_default.xml");
# # detector_b = cv2.CascadeClassifier("./dataset/haarcascade_frontalface_alt.xml");
# # detector_c = cv2.CascadeClassifier("./dataset/haarcascade_frontalface_alt2.xml");
# # detector_d = cv2.CascadeClassifier("./dataset/haarcascade_profileface.xml");
#
# def getImagesAndLabels():
#     continue_loop = True
#     i = 0
#     last_user = 0
#     while(continue_loop):
#        i+=1
#        print(os.path.isdir("./dataset/images/User"+str(i)))
#        if(os.path.isdir("./dataset/images/User"+str(i))):
#            print("User " + str(i) + " exists.")
#            last_user+=1
#        else:
#            # print("Selecting User " + str(i-1) + ".")
#            # path = "./dataset/images/User"+str(i-1)
#            continue_loop = False
#
#     print(last_user)
#     ids = np.intc([])
#     faceSamples = []
#     for user_id in range(1,last_user+1):
#         print(user_id)
#         path = f"./dataset/images/User{user_id}"
#
#
#         # continue_loop = True
#         # i = 0
#         # while(continue_loop):
#         #    i+=1
#         #    print(os.path.isdir("./dataset/images/User"+str(i)))
#         #    if(os.path.isdir("./dataset/images/User"+str(i))):
#         #        print("User " + str(i) + " exists.")
#         #    else:
#         #        print("Selecting User " + str(i-1) + ".")
#         #        path = "./dataset/images/User"+str(i-1)
#         #        continue_loop = False
#
#         imagePaths = [os.path.join(path,f) for f in os.listdir(path)]
#         for x in imagePaths:
#             #print(cv2.imread(x))
#             print(user_id)
#             faceSamples.append(cv2.imread(x))
#             ids = np.append(ids,user_id)
#
#     return faceSamples,ids
#
# faces,ids = getImagesAndLabels()
# #for x in np.array(ids):
# #    print(x)
# #print(np.array(ids))
# recognizer.train(faces, np.array(ids))
#
# recognizer.write('trainer/trainer.yml')



import cv2, os
import numpy as np
from PIL import Image
recognizer = cv2.face.FisherFaceRecognizer_create()
detector = cv2.CascadeClassifier("./dataset/haarcascade_frontalface_default.xml");
def getImagesAndLabels(path):
    path = "./dataset/images"
    imagePaths = [os.path.join(path,f) for f in os.listdir(path)]
    faceSamples=[]
    ids = []
    for imagePath in imagePaths:
        # print(imagePath)
        PIL_img = Image.open(imagePath).convert('L')
        img_numpy = np.array(PIL_img,'uint8')
        id = int(os.path.split(imagePath)[-1].split(".")[1])
        faces = detector.detectMultiScale(img_numpy)
        for (x,y,w,h) in faces:
            faceSamples.append(img_numpy[y:y+h,x:x+w])
            ids.append(id)
    return faceSamples,ids

faces,ids = getImagesAndLabels('dataset')
recognizer.train(faces, np.array(ids))
recognizer.write('trainer/trainer.yml')
