import tkinter as tk
import os
class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.pack()
        self.create_widgets()

    def create_widgets(self):


        self.data_collection = tk.Button(self)
        self.data_collection["text"] = "1) Run Data Collection Program."
        self.data_collection["command"] = self.run_0
        self.data_collection.pack(side="top")

        self.data_collection = tk.Button(self)
        self.data_collection["text"] = "2) Run Data Training."
        self.data_collection["command"] = self.run_1
        self.data_collection.pack(side="top")

        self.data_collection = tk.Button(self)
        self.data_collection["text"] = "3) Run Privacy Protector"
        self.data_collection["command"] = self.run_2
        self.data_collection.pack(side="top")

        self.data_collection = tk.Button(self)
        self.data_collection["text"] = "Add user"
        self.data_collection["command"] = self.add_user
        self.data_collection.pack(side="right", )

        self.data_collection = tk.Button(self)
        self.data_collection["text"] = "Remove user"
        self.data_collection["command"] = self.remove_user
        self.data_collection.pack(side="right", )

        self.quit = tk.Button(self, text="QUIT", fg="red",
                              command=self.master.destroy)
        self.quit.pack(side="left")






    def run_0(self):
        os.system("python3 0_training_data_collection.py")

    def run_1(self):
        os.system("python3 1_training.py")

    def run_2(self):
        os.system("python3 2_PrivacyProtector.py")

    def add_user(self):
        continue_loop = True
        i = 0
        while(continue_loop):
            i+=1
            print(os.path.isdir("./dataset/images/User"+str(i)))
            if(os.path.isdir("./dataset/images/User"+str(i))):
                print("User " + str(i) + " exists.")
            else:
                print("Creating User " + str(i) + "...")
                os.system("mkdir ./dataset/images/User"+str(i))
                continue_loop = False

    def remove_user(self):
        continue_loop = True
        i = 0
        while(continue_loop):
            i+=1
            print(os.path.isdir("./dataset/images/User"+str(i)))
            if(os.path.isdir("./dataset/images/User"+str(i))):
                print("User " + str(i) + " exists.")
            else:
                print("Removing User " + str(i-1) + "...")
                os.system("rm -rf ./dataset/images/User"+str(i-1))
                continue_loop = False


root = tk.Tk()
app = Application(master=root)
app.mainloop()
